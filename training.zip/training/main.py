import time
import tkinter as Tk
from tkinter import ttk
import serial
import serial.tools.list_ports
import tab_creator.creatTab as creatTab
from tkinter import messagebox
class Application():
    def __init__(self, parent):
        self.parent = parent
        self.frames()
        self.port_names = []
        self.serial_avr = None
        self.status_serial = False
        self.init_serial()
    def scan_serial_port(self):
        port_name = []
        ports = list(serial.tools.list_ports.comports())
        for index in range(len(ports)):
            port_name.append(ports[index][0])
        return port_name

    def scan_ports(self):
        self.port_names = self.scan_serial_port()
        print("kieu cua portname: ", self.port_names)
        self.tab1Bt4.configure(text="Active port"+"\n"+str(self.port_names[0])+"\n"+"Ready")

    def init_serial(self):
        self.status_serial = False
        try:
            self.serial_avr = serial.Serial(port='COM3', baudrate=9600,
                                       bytesize=serial.EIGHTBITS, parity=serial.PARITY_NONE,
                                       stopbits=serial.STOPBITS_ONE, timeout=0)
            time.sleep(2)
            print("Initializing...")
            # print('ten tap la:',str(self.port_names[0]))
            if self.serial_avr.isOpen():
                self.status_serial=True
                print('KET NOI TOT')
            else:
                self.status_serial = False

        except(serial.SerialException, ValueError) as ex:
            messagebox.showerror("Result", "Can not open serial port"+ str(ex))

    def run_callback(self):
        if self.status_serial:
            self.serial_avr.write(b'a')
            print('OK')
    def run_revert_callback(self):
        if self.status_serial:
            self.serial_avr.write(b'b')
            print('OK')

    def frames(self):
        style = ttk.Style()
        style.configure('TNotebook.Tab', width=50, height=50, font=('Helvetica', 20), relief='raised', fg='red')
        style.configure('TNotebook', tabposition='s', font=('Helvetica', 18), fg='red')
        note = ttk.Notebook(root, cursor="arrow", height=2000, width=200, style='TNotebook')
        [self.tab1, self.tab2, self.tab3] = creatTab.CRT.creattab(note)
        [self.tab1Frame1, self.tab1Frame2, self.tab1Frame3] = creatTab.CRT.creatFrame(self.tab1)
        [self.tab2Frame1, self.tab2Frame2, self.tab2Frame3] = creatTab.CRT.creatFrame(self.tab2)
        [self.tab3Frame1, self.tab3Frame2, self.tab3Frame3] = creatTab.CRT.creatFrame(self.tab3)

        # tab1 frame
        self.tab1Frame1.pack(side='left')
        self.tab1Frame2.pack(side='left', fill='both', expand='true')
        self.tab1Frame3.pack(side='right', expand='true')
        [self.tab1Bt1, self.tab1Bt2, self.tab1Bt3, self.tab1Bt4] = creatTab.CRT.drawLeftTab(self.tab1Frame1,
                                                                                            ['out of \n service', 'FUNCTION1', 'FUNCTION2',
                                                                                             'SCAN'],
                                                                                            ['disable', 'normal',
                                                                                             'normal', 'normal'],
                                                                                            ['grey', 'cyan', 'cyan',
                                                                                             'cyan'])
        [self.tab1Bt5, self.tab1Bt6, self.tab1Bt7, self.tab1Bt8] = creatTab.CRT.drawRightTab(self.tab1Frame3,
                                                                                             ['ut of \n service', 'FUNCTION3',
                                                                                              'RUN BACKWARD',
                                                                                              'RUN FORWARD'],
                                                                                             ['disable', 'normal',
                                                                                              'normal', 'normal'],
                                                                                             ['grey', 'cyan',
                                                                                              'cyan', 'cyan'])

        # self.tab1Photo = PhotoImage(file="/home/pi/Downloads/project/image/channel1.gif")
        # self.tab1Photo1 = PhotoImage(file="/home/pi/Downloads/project/image/serial1.gif")
        # self.tab1Photo2 = PhotoImage(file="/home/pi/Downloads/project/image/readdata.gif")
        # self.tab6Photo1 = PhotoImage(file="/home/pi/Downloads/project/image/shutdown1.gif")
        self.tab1Bt1.configure(width=12, height=8)
        self.tab1Bt2.configure(width=12, height=9)
        self.tab1Bt3.configure(width=12, height=9)
        self.tab1Bt4.configure(width=12, height=9, command=self.scan_ports)
        self.tab1Bt5.configure(width=12, height=8)
        self.tab1Bt6.configure(width=12, height=9)
        self.tab1Bt7.configure(width=12, height=9, command=self.run_revert_callback)
        self.tab1Bt8.configure(width=12, height=9, command=self.run_callback)

if __name__ == '__main__':
    root = Tk.Tk()
    #root.iconbitmap(r"/home/pi/Downloads/project/image/otani_icon.ico")
    root.geometry("1024x600")
    root.resizable(0,0)
    root.title('DONG CO')
    app = Application(root)
    root.mainloop()